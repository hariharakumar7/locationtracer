package in.studytutorial.mycustomsmsreceiver;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

public class AddDelete extends AppCompatActivity {
    EditText add,delete;
    SQLiteDatabase mydatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_add_delete);
        add= (EditText) findViewById(R.id.add_user);
        delete= (EditText) findViewById(R.id.delete_user);
        mydatabase = openOrCreateDatabase("friendstracker",MODE_PRIVATE,null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS friendstracker(num VARCHAR);");
    }
    public void adduser(View v){
        if(!add.getText().toString().isEmpty()){
        mydatabase.execSQL("INSERT INTO friendstracker VALUES("+"'"+add.getText().toString()+"'"+");");
        Cursor resultSet = mydatabase.rawQuery("Select * from friendstracker;",null);
        add.setText("");
            Toast.makeText(this, "Uploaded Successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    public void delete_user(View v){
        try {
            if(!delete.getText().toString().isEmpty()){
            mydatabase.execSQL("DELETE FROM friendstracker WHERE num='" + delete.getText().toString() + "';");
            Cursor resultSet = mydatabase.rawQuery("Select * from friendstracker where num='"+delete.getText().toString()+"';",null);
            delete.setText("");
                Toast.makeText(this, "Deleted Successfully!", Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Delete operation cannot be performed!",Toast.LENGTH_LONG).show();

        }
    }
}
