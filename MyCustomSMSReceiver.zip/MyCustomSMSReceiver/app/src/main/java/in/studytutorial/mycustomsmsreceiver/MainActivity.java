package in.studytutorial.mycustomsmsreceiver;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    Context ctx;
    String sender="4259791931";
    int flag=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},1);
        ctx=this;
        Intent intent = getIntent();
        sender = intent.getStringExtra("message");
        SQLiteDatabase mydatabase = openOrCreateDatabase("friendstracker",MODE_PRIVATE,null);
        Cursor resultSet = mydatabase.rawQuery("Select * from friendstracker where num='"+sender+"';",null);
        if(resultSet.getCount()<=0){
            this.finish();
            System.exit(0);

        }
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            return;
        }
        Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        int count=0;
        while(location==null) {
            if (count % 2 == 0)
                location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            else location=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (location != null) {
                showMyAddress(location);
            }
            count++;
        }
        if (location != null) {
            showMyAddress(location);
        }
        final LocationListener locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                //showMyAddress(location);
            }
            public void onProviderDisabled(String arg0) {
                // TODO Auto-generated method stub
            }
            public void onProviderEnabled(String arg0) {
                // TODO Auto-generated method stub
            }
            public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
                // TODO Auto-generated method stub
            }
        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 10, locationListener);

    }

    private void showMyAddress(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        Geocoder myLocation = new Geocoder(getApplicationContext(), Locale.getDefault());
        SmsManager sms = SmsManager.getDefault();
        if(sender=="4259791931")
            sms.sendTextMessage(sender, null, "Not Setup Yet!", null, null);
        else
        sms.sendTextMessage(sender, null, "https://www.google.com/maps/search/"+Double.toString(latitude)+","+Double.toString(longitude), null, null);
        this.finish();
        System.exit(0);
        List<Address> myList;
        try {
            myList = myLocation.getFromLocation(latitude, longitude, 1);
            if(myList.size() == 1) { }
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp")) {
                final String message = intent.getStringExtra("message");
                sender=message;
                TextView tv = (TextView) findViewById(R.id.txtview);
                tv.setText(message);
                SQLiteDatabase mydatabase = openOrCreateDatabase("friendstracker",MODE_PRIVATE,null);
                Cursor resultSet = mydatabase.rawQuery("Select * from friendstracker where num='"+sender+"';",null);
                //Toast.makeText(context, sender, Toast.LENGTH_LONG).show();
                Log.e("errorrrrrrrrrrrrrrrrrrr",Integer.toString(resultSet.getCount()));
                if(resultSet.getCount()<=0){
                    flag=1;
                }
            }
        }
    };

    @Override
    public void onResume() {
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter("otp"));
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }

}
